---
id: OBJ-CHAR-06
status: active
kind: surface
authority: current
system: SYS-04
family: projections
storybook: scene
depends_on:
- MEC-003
- OBJ-CHAR-19
- DS-OBJ
platforms:
- web
---

# OBJ-CHAR-06 — Character Focus

Parent: [[OBJ-CHAR — Character Representation Family]]

## Purpose

Complete Character workspace combining fictional identity, roleplay, temporal state, mechanics, relationships, knowledge, story history, references, and private GM material. It replaces a separate Character CRUD/detail page.

## Context & placement

Deepens in the central workspace from the originating Character Placement/reference while preserving Board, viewport, Placement, Stage/Prepare context, and Librarian context. During Stage, Stage Carriage remains left and Librarian remains available right.

## Major content regions

### Identity
Name, aliases, images, PC/NPC/adversary role, pronouns, ancestry/species, role/occupation and relevant identity metadata.

### Summary
Durable prose answer to **who is this person in the story?**

### Roleplay
Personality, voice, mannerisms, tells, beliefs/values, fears, bonds, flaws, secrets and portrayal notes.

### Goals & motives
Immediate wants, long-term goals, fears/avoidances, pressures and conflicting motivations.

### Mechanics
Rendered through [[MEC-003 — Mechanics Layout Renderer]] using the object's assigned full mechanics template/profile.

### Current state
[[OBJ-CHAR-19 — Character Current State Summary]].

### Knowledge & beliefs
Narratively meaningful Knows / Believes / Suspects / Was told entries, with story position/source where important.

### Relationships
Meaningful semantic relationships and their verbs/meaning.

### Threads
Current and historically important narrative Threads.

### History
Meaningful Events/state changes, not an audit log; historical selection can project the same Character as they existed then.

### Inventory / holdings
Narratively or mechanically important items rather than mandatory exhaustive inventory.

### GM material
Private secrets, improvisation, future ideas, hidden motives and reminders.

### Sources & rules references
Evidence for Character content plus mechanics/rules references.

### Librarian
Character Focus automatically becomes Librarian context.

## Mechanics customization

The overall Character Focus remains Relic-designed. The GM can customize or replace the **mechanics block template**, but does not initially freeform-rebuild the entire Focus surface.

## Appearance & behaviour

Deep editorial dossier. Narrative and mechanical blocks may use different density while remaining visually coherent. Wide layouts can use deliberate columns; narrow layouts stack.

## Handoff

Build **OBJ-CHAR-06 — Character Focus** as the complete Character workspace composed from Relic narrative blocks plus modular game-system mechanics.
