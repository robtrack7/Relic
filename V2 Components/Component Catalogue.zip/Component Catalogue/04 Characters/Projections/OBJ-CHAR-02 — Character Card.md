---
id: OBJ-CHAR-02
status: active
kind: component
authority: current
system: SYS-04
family: projections
storybook: component
depends_on:
- BRD-006
- OBJ-CHAR-03
- DS-OBJ
platforms:
- web
---

# OBJ-CHAR-02 — Character Card

Parent: [[OBJ-CHAR — Character Representation Family]]

## Purpose

Normal Desk representation answering **who is this person and why do they matter here?** without reproducing the full Character record.

## Context & placement

Displayed through [[BRD-006 — Placement Host]] on ordinary Desk/Boards and on the central Canvas during Stage. It is the same component in both contexts.

## Anatomy

### Primary
- portrait/image when available;
- Character name;
- short role / occupation / identity phrase.

### Secondary
- concise current summary;
- one or two high-value contextual cues: current Place, important Faction, status, or active Thread relevance.

### Quiet metadata
- PC/NPC cue where useful;
- Pencil/Ink;
- provenance only when noteworthy.

## Appearance & behaviour

Small editorial dossier/index-card quality. Name is dominant. Strong imagery can shape the card; image-less cards remain deliberately composed. Hover/selection reveals secondary controls. Intentional enlargement moves to [[OBJ-CHAR-03 — Expanded Character Card]].

## Explicit exclusions

No full mechanics, full roleplay notes, detailed relationships, full knowledge, Event history, inventory, or long GM notes.

## Handoff

Build **OBJ-CHAR-02 — Character Card** as the standard narrative-first Character projection shared by ordinary Desk and Stage Canvas.
