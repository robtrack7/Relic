---
id: OBJ-CHAR-03
status: active
kind: component
authority: current
system: SYS-04
family: projections
storybook: component
depends_on:
- OBJ-016
- OBJ-CHAR-04
- OBJ-CHAR-05
- DS-OBJ
platforms:
- web
---

# OBJ-CHAR-03 — Expanded Character Card

Parent: [[OBJ-CHAR — Character Representation Family]]

## Purpose

Richer in-place Character representation for substantially more information while retaining spatial context. It is two-sided.

## Context & placement

Occupies the same Placement identity and uses [[OBJ-016 — Two-Sided Expanded Card Host]].

## Anatomy

- [[OBJ-CHAR-04 — Expanded Character Front]] — narrative face;
- [[OBJ-CHAR-05 — Expanded Character Mechanics Back]] — abbreviated mechanics face;
- [[OBJ-017 — Expanded Card Flip Control]] — upper-right external control.

## Use

Useful during worldbuilding, preparation, Stage, and encounter reference when the Character should stay spatially present but carry more working information.

## Appearance & behaviour

Front is narrative-first; back mechanics-first. Full detail remains in Focus. Face state is Board-local presentation state.

## Handoff

Build **OBJ-CHAR-03 — Expanded Character Card** as the two-sided richer Desk/Stage Character representation.
