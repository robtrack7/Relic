---
id: OBJ-017
status: active
kind: component
authority: current
system: SYS-03
family: expanded-cards
storybook: component
depends_on:
- DS-FND-MOTION
- DS-OBJ
platforms:
- web
---

# OBJ-017 — Expanded Card Flip Control

Parent: [[OBJ-016 — Two-Sided Expanded Card Host]]

## Purpose

Provides the small persistent affordance for turning an eligible Expanded Card between front and back.

## Context & placement

Anchored just outside the **upper-right edge of the Expanded Card**. It travels with the Placement but sits outside card content so it does not consume layout space.

## Anatomy

- small turn/flip symbol;
- accessible label/tooltip such as `Show mechanics` or `Show character`.

## Appearance & behaviour

A tiny physical-card affordance rather than another toolbar button. Quiet at rest, clearer on hover/focus. Used identically on ordinary Desk and Stage Canvas.

## States & variants

- front active;
- back active;
- hover/focus;
- transition in progress.

## Handoff

Build **OBJ-017 — Expanded Card Flip Control** as the small upper-right external face-switch affordance for two-sided Expanded Cards.


## Transition contract

Use a restrained shallow 3D turn around the vertical axis, swapping faces around midpoint. Avoid collectible-card theatrics. Reduced-motion mode uses a restrained crossfade/immediate replacement.

The flip must preserve object identity, card position, and deliberate disclosure continuity. Respect reduced motion.
