---
id: FOC-005
status: active
kind: behavior
authority: current
system: SYS-06
family: focus-host-navigation
storybook: none
depends_on:
- FOC-004
- FOC-006
- APP-010
- DS-FOC
---

# FOC-005 — Focus Layout System

Parent: [[FOC-001 — Focus Host]]

## Purpose

Turns a family Focus composition into a responsive editorial layout that remains readable beside Stage and Librarian carriages.

## Layout model

Supports deliberate layout regions such as:
- primary reading column;
- secondary utility column;
- narrow contextual column;
- full-width block;
- inset/paired block.

Family compositions choose regions and priority.

The system should not automatically masonry-pack every block into whichever column has room.

The Desk currently exposes this hierarchy through a right-docked inspection projection beside Librarian. It overlays a stable Canvas, shares the carriage header alignment and gutters, and leaves the lower-right view controls accessible. This compact dossier and the abbreviated Expanded Card remain distinct from the full central Focus workspace. Section navigation opens the requested disclosure and anchors its reading position.

## Responsive behaviour

**Wide**
Can use multiple deliberate columns.

**Medium**
Collapse secondary/contextual columns into one or two reading columns.

**Stage + Librarian**
Preserve both carriages when central Focus width remains useful; simplify Focus layout first.

**Narrow**
Stack blocks according to family composition order.

Section Navigator collapses to a compact Focus menu.

## Appearance & behaviour

Spacing, headings, rules, and typography should create document rhythm.

Blocks are not automatically surrounded by cards.

Full-width media/mechanics/history sections can break the primary reading column when the family composition calls for it.

## Relationships

- [[FOC-004 — Focus Composition Contract]] — supplies order/emphasis.
- [[FOC-006 — Focus Section Navigator]] — maps to rendered section anchors.
- [[APP-010 — Workspace Dock Manager]] — supplies usable central bounds.

## Handoff

Implement **FOC-005 — Focus Layout System** as the responsive editorial layout engine for family-specific Focus compositions.
