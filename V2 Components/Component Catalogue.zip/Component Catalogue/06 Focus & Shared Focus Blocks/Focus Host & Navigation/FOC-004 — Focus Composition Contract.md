---
id: FOC-004
status: active
kind: behavior
authority: current
system: SYS-06
family: focus-host-navigation
storybook: none
depends_on:
- FOC-005
- DS-FOC
---

# FOC-004 — Focus Composition Contract

Parent: [[FOC-001 — Focus Host]]

## Purpose

Defines how each World Object family declares a deliberate Focus composition using shared blocks without creating one generic universal Focus page.

## Composition model

A family Focus declares:
- block order;
- block presence;
- section labels;
- relative emphasis;
- layout region preference;
- optional family-specific blocks;
- which blocks are temporally aware;
- which blocks can disappear when empty;
- which blocks should expose an add-content affordance.

Example Character order:
1. Identity
2. Media
3. Narrative
4. Roleplay
5. Goals
6. Mechanics
7. Status
8. Location
9. Knowledge
10. Relationships
11. Threads
12. Event History
13. Inventory
14. GM Notes
15. Sources

A Place or Event Focus declares a different composition.

## Boundaries

The family Focus owns composition.

The shared Focus Block owns its internal anatomy/behavior.

The GM does not initially drag/reorder the entire Focus page.

The contract should not render every registered block merely because the system supports it.

## Relationships

- [[FOC-005 — Focus Layout System]] — turns composition declarations into responsive layout.
- reusable FOC-BLK components — supply shared semantic blocks.
- World Object family Focus surfaces — declare the actual compositions.

## Handoff

Implement **FOC-004 — Focus Composition Contract** as the family-declared block order/presence/emphasis model for Focus surfaces.
